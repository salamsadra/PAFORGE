"""PA-FORGE: research-grade architecture with intentionally approximate MVP solvers.

The MVP has not been validated against a human experimental acquisition.
"""
__version__ = "0.5.0"
