"""Interactive Gradio control panel. Runs locally, no cloud data transfer."""
import tempfile
import zipfile
from pathlib import Path
from .config import preset,SimConfig
from .pipeline import run_batch
from .io import plot_preview


def _bundle(folder):
    archive=folder/"pa_forge_outputs.zip"
    with zipfile.ZipFile(archive,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=3) as z:
        for f in folder.rglob("*"):
            if f.is_file() and f!=archive:z.write(f,f.relative_to(folder))
    return str(archive)


def generate_ui(anatomy,samples,seed,noise_enabled,noise_engines,noise_std,empirical_path,
                wavelength,transducers,geometry,center_mhz,bandwidth_mhz,
                sound_var,scattering,laser_jitter,dropout,grid,time_steps,
                vascular_pattern,vascular_branches,vascular_density,
                recon_method,recon_iterations,filter_enabled,
                illumination,anatomy_engine,generator_weights):
    base=preset(anatomy)
    config={**base.model_dump(),"samples":int(samples),"seed":int(seed),
            "grid_size":int(grid),"time_steps":int(time_steps),
            "vascular_pattern":vascular_pattern,"vascular_branch_levels":int(vascular_branches),
            "vascular_density":vascular_density,"reconstruction_method":recon_method,
            "illumination_model":illumination,"anatomy_engine":anatomy_engine,
            "generator_weights":generator_weights.strip() or None,
            "reconstruction_iterations":int(recon_iterations),"detector_filter":bool(filter_enabled),
            "wavelength_nm":int(wavelength),"transducers":int(transducers),
            "geometry":geometry,"center_frequency_hz":center_mhz*1e6,
            "bandwidth_hz":bandwidth_mhz*1e6,
            "sound_speed_variation_fraction":sound_var,"scattering_scale":scattering,
            "pulse_energy_jitter_fraction":laser_jitter,
            "channel_dropout_probability":dropout,
            "noise":{"enabled":bool(noise_enabled),"engines":noise_engines,
                     "relative_std":noise_std,"empirical_path":empirical_path.strip() or None}}
    cfg=SimConfig.model_validate(config)
    output=Path(tempfile.mkdtemp(prefix="paforge_"))
    results=run_batch(cfg,output)
    overview=plot_preview(results[0])
    archive=_bundle(output)
    import json
    return str(overview),archive,json.dumps({"config":cfg.model_dump(mode="json"),"output_dir":str(output)},indent=2)



def _load_reference(reference_path):
    import numpy as np
    if not reference_path or not str(reference_path).strip():
        return None
    p=Path(str(reference_path).strip().strip('"'))
    if not p.is_file() or p.suffix.lower()!='.npy':
        raise ValueError('Reference path must point to an existing .npy file')
    a=np.load(p,allow_pickle=False)
    if a.ndim!=2:
        raise ValueError('Reference must be a 2D NumPy image')
    return a


def _preview_panel(reconstruction,reference=None,rotation=0,flip_lr=False,flip_ud=False):
    import numpy as np
    from matplotlib import colormaps
    from PIL import Image
    def picture(data,rotate=False):
        if data is None:return None
        a=np.asarray(data,dtype=float)
        if rotate:
            a=np.rot90(a,int(rotation)//90)
            if flip_lr:a=np.fliplr(a)
            if flip_ud:a=np.flipud(a)
        a=np.nan_to_num(a,nan=0,posinf=0,neginf=0)
        lo,hi=np.percentile(a,[1,99.5])
        scaled=np.clip((a-lo)/max(float(hi-lo),1e-12),0,1)
        return (colormaps['magma'](scaled)[:,:,:3]*255).astype(np.uint8)
    return picture(reconstruction,True),picture(reference)


def _experimental_dashboard_reconstruct(local_path,uploaded_file,reference_path,method,fov_mm,grid_size,speed,rotation,flip_lr,flip_ud):
    import h5py
    import numpy as np
    import json
    import tempfile
    import zipfile
    from .experimental_reconstruction import reconstruct_experimental
    from .research_inputs import hdf5_inventory
    src=str(local_path or '').strip().strip('"')
    if not src and uploaded_file:
        src=str(uploaded_file)
    if not src or not Path(src).is_file():
        raise ValueError('Provide an existing local normalized PA-FORGE HDF5 path or upload that HDF5 file')
    with h5py.File(src,'r') as f:
        if 'raw_data' not in f or 'detector_positions_m' not in f:
            raise ValueError('This panel expects a normalized acquisition with /raw_data and /detector_positions_m. Use extract-acquisition first; raw IPASC is not directly interchangeable.')
        shape=f['raw_data'].shape
        pos=f['detector_positions_m'][:]
        fs=float(f.attrs.get('sampling_rate_hz',0))
        synthetic=bool(f.attrs.get('synthetic',False))
    if shape[0]!=pos.shape[0] or len(shape)!=2:raise ValueError('Detector count and signals shape mismatch')
    if np.ptp(pos[:,2])>0.002:raise ValueError('Significant 3D spread; this panel only supports justified planar 2D data')
    output=Path(tempfile.mkdtemp(prefix='paforge_real_dashboard_'))
    rec=reconstruct_experimental(src,output,method=method,fov_m=float(fov_mm)/1000,grid_size=int(grid_size),sound_speed_m_s=float(speed))
    ref=_load_reference(reference_path)
    left,right=_preview_panel(rec,ref,rotation,flip_lr,flip_ud)
    description={'source':src,'signals_shape':list(shape),'sampling_rate_hz':fs,'detector_count':int(shape[0]),'synthetic':synthetic,'reconstruction_method':method,'fov_mm':float(fov_mm),'grid_size':int(grid_size),'assumed_sound_speed_m_s':float(speed),'reference_shape':list(ref.shape) if ref is not None else None,'display_rotation_ccw_deg':int(rotation),'display_flip_lr':bool(flip_lr),'display_flip_ud':bool(flip_ud),'warning':'Qualitative 2D reconstruction only. Visual transformations apply to preview only; physical registration and calibration are not established.'}
    (output/'dashboard_run.json').write_text(json.dumps(description,indent=2),encoding='utf-8')
    archive=_bundle(output)
    return left,right,json.dumps(description,indent=2),archive,rec,ref


def _display_orient(rec,ref,rotation,flip_lr,flip_ud):
    if rec is None:return None,None
    return _preview_panel(rec,ref,rotation,flip_lr,flip_ud)


def _summarize_acquisition(path,uploaded):
    import h5py, json, numpy as np
    source=str(path or '').strip().strip('"') or str(uploaded or '')
    if not source or not Path(source).is_file():return 'Select an HDF5 acquisition to inspect.'
    with h5py.File(source,'r') as f:
        info={'file':source,'datasets':{k:list(f[k].shape) for k in ('raw_data','detector_positions_m') if k in f},'attributes':{k:str(v) for k,v in f.attrs.items()}}
        if 'detector_positions_m' in f:
            p=f['detector_positions_m'][:]
            info['coordinate_spread_m']=(np.ptp(p,axis=0)).tolist()
    return json.dumps(info,indent=2)


def build_ui():
    import gradio as gr
    with gr.Blocks(title="PA-FORGE | Synthetic Photoacoustic Data") as demo:
        with gr.Tab("01 · Synthetic Generator"):
            gr.Markdown("# PA-FORGE · Photoacoustic Data Generator\n**Local research prototype.** 2D approximate physics; no experimental realism certification.")
            with gr.Row():
                with gr.Column(scale=2):
                    anatomy=gr.Dropdown(["forearm","skin","breast","carotid","vascular"],value="vascular",label="Anatomical region")
                    samples=gr.Slider(1,25,value=1,step=1,label="Samples in this interactive run")
                    seed=gr.Number(value=42,precision=0,label="Reproducibility seed")
                    with gr.Accordion("Vascular network (arteries, veins, capillaries)",open=True):
                        vascular_pattern=gr.Dropdown(["branching","paired","plexus"],value="branching",label="Network pattern (vascular mode)")
                        vascular_branches=gr.Slider(1,5,value=3,step=1,label="Branch levels")
                        vascular_density=gr.Slider(.2,3,value=1,step=.1,label="Capillary density multiplier")
                    with gr.Accordion("Reconstruction",open=True):
                        recon_method=gr.Dropdown(["ubp","das","adjoint","iterative"],value="ubp",label="Reconstruction method")
                        recon_iterations=gr.Slider(1,50,value=8,step=1,label="Iterative solver steps")
                        filter_enabled=gr.Checkbox(value=True,label="Apply detector bandpass (turn OFF for matched iterative inversion)")
                    with gr.Accordion("Learned vs procedural anatomy",open=False):
                        anatomy_engine=gr.Dropdown(["procedural","cvae","vascular_cvae"],value="procedural",label="Anatomy generator")
                        generator_weights=gr.Textbox(value="",label="Trusted local model weights path (required for cVAE)")
                    with gr.Accordion("Noise engines · completely optional",open=True):
                        noise=gr.Checkbox(value=False,label="Enable added noise (OFF by default)")
                        engines=gr.CheckboxGroup(["gaussian","colored","impulsive","drift","empirical"],value=["gaussian"],label="Active engines (only run when enabled)")
                        strength=gr.Slider(0,0.3,value=.025,step=.005,label="Noise SD relative to clean waveform RMS")
                        empirical=gr.Textbox(label="Trusted local empirical noise path (required when engine selected)",value="")
                    with gr.Accordion("Acquisition and device settings",open=False):
                        illumination=gr.Dropdown(["attenuation_proxy","uniform_idealized"],value="uniform_idealized",label="Optical fluence model (uniform is idealized; scattering ignored)")
                        wavelength=gr.Slider(660,1300,value=800,step=10,label="Laser wavelength (nm)")
                        transducers=gr.Slider(8,128,value=64,step=8,label="Transducer count")
                        geometry=gr.Dropdown(["circle","arc","linear"],value="circle",label="Acquisition geometry")
                        center=gr.Slider(.4,3,value=1.8,step=.1,label="Detector center frequency (MHz)")
                        bandwidth=gr.Slider(.3,3,value=1.8,step=.1,label="Detector bandwidth (MHz)")
                        sound=gr.Slider(0,2,value=1,step=.1,label="Sound speed anatomical variation multiplier")
                        scattering=gr.Slider(.1,3,value=1,step=.1,label="Optical reduced scattering multiplier")
                        laser=gr.Slider(0,.2,value=0,step=.005,label="Pulse energy jitter fraction")
                        drop=gr.Slider(0,.5,value=0,step=.01,label="Channel dropout probability")
                        grid=gr.Dropdown([64,96,128],value=96,label="Spatial grid points per dimension")
                        steps=gr.Slider(200,800,value=380,step=20,label="Time steps")
                    # Keep anatomy-specific geometry defaults when switching regions.
                    anatomy.change(fn=lambda a: gr.update(value=preset(a).geometry),inputs=anatomy,outputs=geometry)
                    anatomy.change(fn=lambda a: gr.update(value=preset(a).illumination_model),inputs=anatomy,outputs=illumination)
                    recon_method.change(fn=lambda m: gr.update(value=False) if m=="iterative" else gr.update(),
                                        inputs=recon_method,outputs=filter_enabled)
                    # Only a well-documented default geometry should change with anatomy.
                    button=gr.Button("Generate simulated signals and images",variant="primary")
                with gr.Column(scale=3):
                    gr.Markdown("### Outputs · raw signals and images stored separately")
                    preview=gr.Image(type="filepath",label="Initial pressure · measured traces · image reconstruction")
                    archive=gr.File(label="ZIP containing HDF5 raw signals, reconstructed image, and truth")
                    metadata=gr.Code(label="Reproducible configuration",language="json")
            button.click(fn=generate_ui,inputs=[anatomy,samples,seed,noise,engines,strength,empirical,
                           wavelength,transducers,geometry,center,bandwidth,sound,scattering,laser,drop,grid,steps,
                           vascular_pattern,vascular_branches,vascular_density,recon_method,recon_iterations,filter_enabled,
                           illumination,anatomy_engine,generator_weights],
                         outputs=[preview,archive,metadata])
            gr.Markdown("**Important:** No added noise ≠ noiseless real hardware. IPASC conformance and patient-data realism remain unvalidated.")
        with gr.Tab("02 · Experimental Reconstruction"):
            gr.Markdown("### Reconstruct measured acquisitions | 2D · qualitative\nUse **normalized PA-FORGE HDF5** with measured positions. For original IPASC files, run the existing `extract-acquisition` command first. Orientation controls affect **display only**, not raw measurements or reconstructed numeric data.")
            with gr.Row():
                with gr.Column(scale=2):
                    real_path=gr.Textbox(label="Normalized acquisition HDF5 (local path)",placeholder="data/real/invision_P.5.10.2_700.h5")
                    real_upload=gr.File(label="Or upload normalized HDF5",file_types=[".h5",".hdf5"],type="filepath")
                    reference_path=gr.Textbox(label="Optional reference reconstruction (.npy, local path)",placeholder="data/selected_invision/invision/recon/P.5.10.2_700.npy")
                    with gr.Row():
                        real_method=gr.Dropdown(["ubp","das"],value="ubp",label="Method")
                        real_grid=gr.Dropdown([64,96,128,192,256],value=256,label="Reconstruction grid")
                    with gr.Row():
                        real_fov=gr.Slider(5,150,value=60,step=1,label="FOV (mm); provisional until calibrated")
                        real_speed=gr.Slider(1000,2200,value=1500,step=10,label="Assumed sound speed (m/s)")
                    gr.Markdown("**Image orientation** (preview-only; never changes the HDF5 signal or reconstructed numerical image)")
                    with gr.Row():
                        rotation=gr.Dropdown([0,90,180,270],value=0,label="Counterclockwise rotation (°)")
                        flip_lr=gr.Checkbox(value=False,label="Flip left ↔ right")
                        flip_ud=gr.Checkbox(value=False,label="Flip up ↕ down")
                    inspect=gr.Button("Inspect acquisition metadata")
                    real_run=gr.Button("Reconstruct acquisition",variant="primary")
                    real_meta=gr.Code(language="json",label="Run / acquisition metadata")
                with gr.Column(scale=3):
                    with gr.Row():
                        real_image=gr.Image(label="PA-FORGE reconstruction (display orientation)",type="numpy")
                        real_reference=gr.Image(label="Published reference (unchanged orientation)",type="numpy")
                    gr.Markdown("Reference images can have a different field of view and pixel scale. Side-by-side does **not** constitute registered or quantitative comparison.")
                    real_zip=gr.File(label="Download reconstructed numeric HDF5 + original PNG + manifest + settings")
            rec_state=gr.State(None)
            ref_state=gr.State(None)
            inspect.click(fn=_summarize_acquisition,inputs=[real_path,real_upload],outputs=real_meta)
            real_run.click(fn=_experimental_dashboard_reconstruct,inputs=[real_path,real_upload,reference_path,real_method,real_fov,real_grid,real_speed,rotation,flip_lr,flip_ud],outputs=[real_image,real_reference,real_meta,real_zip,rec_state,ref_state])
            for transform in (rotation,flip_lr,flip_ud):
                transform.change(fn=_display_orient,inputs=[rec_state,ref_state,rotation,flip_lr,flip_ud],outputs=[real_image,real_reference])
        with gr.Tab("03 · Release notes & guardrails"):
            gr.Markdown("""## PA-FORGE — Local research workspace

- **Synthetic:** Physically motivated 2D wave simulation, procedural / optional trained CVAE phantom inputs, selectable noise, UBP/DAS/adjoint/iterative reconstruction.
- **Experimental:** Real measured acquisition in normalized HDF5; actual detector coordinates; exploratory 2D homogeneous-speed UBP or DAS.
- **Orientation:** Rotation and flips are **visual only**. The numerical reconstructions and measured signals remain unchanged. Use published device coordinate conventions for scientific registration.
- **No full 3D acoustics:** The simulation and experimental reconstruction are 2D, even if 3-component positions are stored.
- **No automatic real-image certification:** FOV, device response, sound speed and reference alignment need external verification.
- **CVAE models:** Optional methods require user-provided trained model weights; no pretrained clinically validated weights are bundled.
- **Local-only workflow:** Uploaded acquisition files are handled by the local Gradio app. Do not expose the local server publicly with sensitive data.

The original acoustic, optical, data generation, and reconstruction modules were **not modified** in this UI update.
""")
    return demo
