# PA-FORGE v0.5.1 UI-only Dashboard Update

No changes to physical simulation, acoustic forward/adjoint, reconstruction, noise, or dataset ingestion algorithms.

## Changes

- Tab 1: original synthetic phantom + acoustic simulation + reconstruction controls.
- Tab 2: normalized real-measurement HDF5 inspection and 2D qualitative UBP/DAS reconstruction, with user-specified FOV, homogeneous speed and grid size.
- Optional local reference .npy image comparison; original reference displayed without transforms.
- Display-only rotate (0,90,180,270 CCW), left-right flip, up-down flip. Reconstructed numerical HDF5, raw measurements and original reconstruction PNG remain unchanged.
- Output downloadable archive includes numerical reconstruction and manifest; UI settings separately recorded in dashboard_run.json.
- Tab 3: provenance and scientific limitations.

## Run on Windows without virtualenv

From the *PA-FORGE-v0.5* directory:

    py -m pip install -e ".[dev,ui,train]"
    py -m pytest -q
    py -m paforge.cli ui

Open the localhost address printed to the PowerShell terminal (default http://127.0.0.1:7860).

## InVision user data path (after extraction already completed)

- Normalized HDF5: data/real/invision_P.5.10.2_700.h5
- Optional published reference: data/selected_invision/invision/recon/P.5.10.2_700.npy
- Method UBP, grid 256, FOV 60 mm, assumed sound speed 1500 m/s
- Set 90 degree rotation for a qualitative orientation check, then adjust if necessary. The control only changes preview orientation.

## Scientific status

Image orientation is a user interface operation, not certified spatial registration. Quantitative reconstruction, device calibration, artifact suppression, 3D reconstruction, full input-format interoperability, and trained real-data anatomical priors remain future work. No experiment on the user's actual InVision archive was performed in this environment. Tests use synthetic fixtures only.
