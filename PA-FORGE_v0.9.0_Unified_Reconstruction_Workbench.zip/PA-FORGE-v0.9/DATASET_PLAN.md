# Dataset plan — v0.7.0

The live Dataset Wizard in Tab 03 is the source of truth for current publisher file sizes, checksums, mandatory assets and storage preflight. It discovers Zenodo metadata at runtime and saves `data/external/dataset_plan.json`.

Default research objectives:
- `experiment_informed_generation`: OpenQPAIData is mandatory.
- `full_research_corpus`: OpenQPAIData and Digital Twin QA are mandatory.
- `digital_twin_qa`: Digital Twin QA only.
- `custom`: user-selected sources.

Profiles: `auto`, `starter`, `recommended`, `complete`. Complete means every public asset discovered for selected publisher records. Full OpenQPAIData includes the 19.8 GB SVOT archive; SVOT has 3D reference volumes but no shared raw time-series. The Digital Twin archive remains separate from material-CVAE training.
