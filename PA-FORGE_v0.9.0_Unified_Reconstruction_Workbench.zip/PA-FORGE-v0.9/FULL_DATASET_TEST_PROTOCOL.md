# Full Dataset Test Protocol — PA-FORGE v0.7.0

## Objective
Run the complete OpenQPAIData multi-device corpus and the Digital Twin full-reference QA archive through PA-FORGE's download, inventory, material-learning, generation and visual-audit workflows.

## Expected download
- OpenQPAIData complete record: approximately 20.5 GB.
- Digital Twin complete record: approximately 2.9 GB.
- Combined: approximately 23.4 GB compressed.
- Keep at least 2 GB additional free disk space for the downloader reserve. More space is needed if users manually extract or duplicate archives.

## Phase A — Download
1. Launch `START_PA_FORGE.bat`.
2. Open Tab 03 · Intelligent Dataset Hub.
3. Select **Complete research corpus · OpenQPAIData + Digital Twin**.
4. Select `openqpai` and `digital-twin-iqa`.
5. Select **Complete** profile.
6. Click Discover datasets and calculate download plan.
7. Review each publisher asset and the disk preflight.
8. Review license terms and acknowledge them.
9. Click Download planned datasets; allow resumable downloads to finish.
10. Inspect the final JSON report; all required assets should be `downloaded` or `already_verified`.

## Phase B — Archive inventory
1. In Tab 03, inspect downloaded ZIP archives without extracting them.
2. Verify that `DIS.zip`, `invision.zip`, `tropus.zip`, `svot.zip` and Digital Twin `data.zip` are present.
3. Save `archive_inventory.json` and check role counts and top-level structures.

## Phase C — Full OpenQPAIData corpus preparation

For the simplest end-to-end test, use the **One-click complete workflow · download → prepare → train → generate** accordion in Tab 04 after the plan is created and licenses are acknowledged. It performs Phases B–E and packages the generated workflow artifacts (not a duplicate of the downloaded 23.4 GB source archives).

For a staged run with inspection between steps:
1. Open Tab 04 · Learn from OpenQPAIData.
2. Set paths to all five OpenQPAIData assets: InVision, TROPUS, SVOT, DIS and material_mapping.json.
3. Declare mapped InVision/TROPUS optical units as 1/cm according to publisher documentation.
4. Choose 6 SVOT slices per 3D label volume for the first full run.
5. Click Prepare complete multi-device material + optical corpus.
6. Save the ingestion report, optical profile, DIS inventory and corpus NPZ.
7. Confirm the unique phantom-group count, device mask counts, SVOT slice count, and train/validation/test group lists.

## Phase D — Training
1. Install PyTorch CPU from Tab 00 if it is not already installed.
2. Train the material CVAE with 20–50 epochs initially and batch size 4–8.
3. Save the checkpoint, training curve and held-out report.
4. Confirm no phantom IDs overlap across train, validation and test.

## Phase E — Generation
1. Open Tab 05.
2. Select the trained material CVAE and train-only optical profile.
3. Begin with 10 samples, 64×64 grid, 700 nm (only if present in the profile), and noise OFF.
4. Generate raw detector signals and reconstructed images.
5. Inspect ground-truth labels, initial pressure, raw sinograms, selected time traces, reconstructions and intensity distributions.
6. Increase sample count only after the smoke run succeeds.

## Phase F — Digital Twin QA
The Digital Twin archive is retained as an independent full-reference QA source, not merged into the material-CVAE training set. Inspect its archive inventory and schema first. Only add a dedicated adapter after its internal files, coordinate conventions and metadata have been verified. Do not treat a generic ZIP inventory as ingestion or calibration.

## Pass criteria
- All planned assets are checksum-verified when publisher checksums exist.
- No unexplained missing required files.
- Full OpenQPAIData inventory identifies InVision/TROPUS raw signals and 2D labels/maps, DIS processed optical assets, and SVOT volumetric labels/reconstructions.
- Multi-device preparation completes with group-disjoint splits.
- CVAE trains without class/wavelength/profile errors.
- Generated samples contain separate ground-truth, raw signal, reconstruction and manifest files.
- Visual diagnostics are readable and provenance is correct.

## Scientific non-claims
Passing this protocol does not establish clinical realism, experimental calibration, 3D acoustic modelling, or simulation-to-real accuracy. Those require separate held-out experimental validation and calibrated device physics.
