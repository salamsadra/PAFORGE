# PATbox MATLAB compatibility / port audit — v0.9

**Status: independent Python implementations and a method-name mapping, NOT a verified source-to-source MATLAB port.**

The user-supplied Zenodo link `https://zenodo.org/records/23348355` did not provide retrievable MATLAB source files during this build. Without the exact `.m` source, numerical test vectors and license terms, claiming a faithful copy or bitwise/semantic equivalence would be scientifically unsound.

| Candidate PATbox method family | Available PA-FORGE v0.9 name | Important difference / caveat |
|---|---|---|
| DAS | `das` | Straight-ray travel-time interpolation |
| CF-DAS | `cf_das` | Pixelwise coherence-factor weighting on 2D delays |
| DMAS | `dmas` | Signed square-root DMAS variant, not proven identical |
| DS-DMAS | `ds_dmas` | Second-stage product proxy, requires MATLAB parity test |
| MV-DAS | `mv_das` | Global covariance weighted, NOT local pixelwise Capon |
| VDAS | `vdas` | Variance coherence proxy, not proven identical |
| SCF-DAS | `scf_das` | Sign coherence factor weighting |
| CFMV-DAS | `cfmv_das` | Combines CF and global MV weights |
| FBP | `fbp` | Temporal ramp-filtered delay-and-sum, geometry-dependent |
| UBP | `ubp` | Derivative-weighted *UBP-like* approximation |
| DMAS-UBP | `dmas_ubp` | DMAS of derivative arrivals |
| VDAS-UBP | `vdas_ubp` | Variance-weighted derivative arrivals |
| TR | `time_reversal` | FDTD reverse source injection, not exact boundary-value time reversal |
| ITERATIVE-DAS | `iterative_das` | Residual-feedback DAS with line search |
| ITERATIVE-TR | `iterative_time_reversal` | Iterative FDTD residual-driven reverse injection |

**Mandatory future validation for a true PATbox port:** obtain and inspect each MATLAB implementation and source license; document coordinate and normalization conventions, impulse response/time-zero treatment, and detector geometry; translate method-by-method with controlled example test cases; compare numerical pixel arrays and image quality under identical physical parameters, then label a method a verified port only after passing parity tests. Existing PA-FORGE methods are useful **benchmarks**, not a substitute for that audit.
