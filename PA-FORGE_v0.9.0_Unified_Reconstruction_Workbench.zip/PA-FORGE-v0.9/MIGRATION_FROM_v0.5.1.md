# Upgrade from PA-FORGE v0.5.1 to v0.6 on Windows

**Keep your tested v0.5.1 folder untouched as a backup.** The old synthetic pipeline is preserved; v0.6 adds experimental-phantom learning and more UI controls.

1. Extract the v0.6 release ZIP **beside** `PA-FORGE-v0.5`, rather than extracting it over the old directory.
2. Open PowerShell in the new `PA-FORGE-v0.6` directory.
3. Reuse downloaded data (you do **not** need to download ~375 MB again):

   ```powershell
   New-Item -ItemType Directory -Force "data"
   Copy-Item -Recurse -Force "..\PA-FORGE-v0.5\data\external" ".\data\external"
   ```

   If your old project is not immediately beside the new one, change the source path accordingly. You can instead use the full absolute old data path in dashboard fields.

4. Install this version against the Python interpreter already in use:

   ```powershell
   py -m pip install -e ".[dev,ui,train]"
   py -m pytest -q
   py -m paforge.cli ui
   ```

5. In the dashboard, open **Tab 04 · Learn from OpenQPAIData**. Point it to `data/external/openqpai/invision.zip`. OpenQPAIData documents `mua` and `musp` in **1/cm**; the default is already `1/cm`. Prepare group-split data, train the material CVAE and inspect loss curves.
6. Open **Tab 05 · Experiment-informed Generation**. Choose `material_cvae` with your trained weights, or `empirical_material` with the prepared corpus. Output contains **separate** waveform and reconstructed image files; its provenance is **synthetic informed by published phantom data**.
7. In **Tab 03 · Dataset Hub**, extract the already known `P.5.10.2` at `700 nm` and normalize it automatically. In **Tab 02**, choose `ubp` for fast reconstruction or `fista` with a 110-mm FOV and 64-point grid for approximate, slower physical inversion. Rotation/flip affect **preview only**.

**No MATLAB source was shipped or automatically imported.** The requested PATbox Zenodo record was not verifiable here; see `PATBOX_STATUS.md`.
