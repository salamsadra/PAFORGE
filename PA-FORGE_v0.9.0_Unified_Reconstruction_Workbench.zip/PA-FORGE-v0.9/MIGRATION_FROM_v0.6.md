# Migrating from PA-FORGE v0.6 to v0.7.0

1. Keep the v0.6 folder as a backup.
2. Extract v0.7.0 into a new folder.
3. Keep the existing `data/external/openqpai` and `data/external/digital-twin-iqa` folders. Copy them into the v0.7 folder if you want to reuse downloads; do not copy the 23.4 GB complete archives if they are not present.
4. Run `START_PA_FORGE.bat` or `py setup_and_launch.py`.
5. In Tab 03, create a fresh dataset plan. Existing assets are detected and publisher checksums are verified during download.
6. In Tab 04, use the multi-device preparation button for complete data. The previous InVision-only preparation path remains available.
7. Retrain the material CVAE using the new multi-device corpus. Do not assume a v0.6 checkpoint was trained on the new device-balanced corpus.

The source code, CLI and UI have new v0.7.0 functionality. Dataset files are not modified by migration.
