# Migrating PA-FORGE v0.8 → v0.9

1. Keep the v0.8 folder intact. Extract v0.9 next to it, not on top of it.
2. Double-click `START_PA_FORGE.bat`, or from PowerShell run `py -m pip install -e ".[ui,train,dev]"`, `py -m paforge.cli ui`.
3. Reuse previously downloaded datasets by pointing the Dashboard dataset hub to the old `data/external` folder (or copy/link that folder). No data repurchase/re-download is required.
4. Open Tab **10 — Unified Reconstruction Lab** and select the synthetic `raw_signals.h5` or normalized experimental HDF5. Select as many as 12 methods. This is the most direct way to compare data and algorithms on identical signals.
5. For neural learned reconstruction, generate paired **DAS** synthetic sample folders, train in Tab 11, and provide the resulting model path in Tab 10 or the specific generation/reconstruction panel. Without a valid checkpoint learned methods are rejected.
6. If you need the actual PATATO methods, install its optional package in Tab 00. PATATO `patato_bp`, `patato_opencl_bp`, `patato_slow_bp`, `patato_model` are external and require a compatible runtime; some require GPU/OpenCL/JAX.
7. If you need original PATbox MATLAB equivalence, the actual verified MATLAB source and tests must first be supplied. The current independent analogous algorithms are not a verified port.

**Compatibility:** Old YAML/Python/CLI method keys `das`, `ubp`, `adjoint`, `iterative` remain supported. The synthetic and experimental UI now show one shared registered method list, but numerical availability still depends on physical geometry and optional dependencies.
