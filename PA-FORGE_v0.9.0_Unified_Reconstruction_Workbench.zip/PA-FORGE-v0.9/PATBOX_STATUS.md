# PATbox / Zenodo 23348355 — source provenance and porting status

Requested reference: https://zenodo.org/records/23348355

**Status as of 2026-11-09:** The record and source files could not be opened or independently identified through the available web/API access, nor was the MATLAB source archive included in the conversation attachments. The precise algorithms, implementation, license, and compatibility are therefore **unverified**. No code in this project is represented as a faithful PATbox port.

**Available now:** Independent Python baselines include unweighted DAS, derivative-weighted UBP-like reconstruction, bandpass-filtered UBP, discretely adjoint 2D FDTD, and constrained L2-regularized FISTA, all clearly marked as exploratory. `paforge/recon_plugins.py` accepts **trusted locally installed** Python reconstruction modules implementing its documented function contract; this is not a MATLAB compatibility layer.

**To produce a legitimate port:** Obtain the actual MATLAB source and license; inventory the reconstruction math, geometry, detector weighting, prefiltering, units and numerics; translate algorithms with separate provenance and attribution; create MATLAB-vs-Python numerical agreement tests on identical fixtures and experimental data. None of those steps can be claimed completed without the actual source.

**v0.8 update:** The Cambridge link in this work is PATATO example data, a Python-compatible HDF5 source (documented separately). The new `patato_bridge.py` is a documented raw data format converter, **not** a port of the separate unverified Zenodo MATLAB/PATbox record.
