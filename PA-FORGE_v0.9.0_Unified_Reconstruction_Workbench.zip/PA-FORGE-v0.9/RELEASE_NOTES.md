# PA-FORGE v0.9.0 — Release notes

## Added

- Canonical `Acquisition` and 33-method reconstruction registry for **both** simulated and measured raw detector traces.
- 13 analytic/beamforming families including independent PATbox-style variants; 4 FDTD wave approaches; 8 matrix-free ray inverse methods; 4 learning approaches; 4 optional official PATATO backends.
- Genuine approximate ray forward and adjoint pair; dot-product adjoint test and validation of 2D measured positions and sampling rate.
- New U-Net and residual CNN image-domain supervised training with split-by-source group, safe PyTorch checkpoint loading and CPU/CUDA/MPS selection.
- Optional per-acquisition self-supervised Deep Image Prior neural reconstruction.
- Official PATATO Python API connector using documented HDF5 data format, no invented detector geometry or optical wavelength. Optional one-click PATATO dependency installer.
- Unified dashboard reconstruction lab and image/sinogram comparison charts, per-method failure reports, method catalog, trained checkpoint selection and dedicated learned reconstruction training tab.
- New CLI commands `reconstruction-methods`, `reconstruct-compare`, `train-reconstruction` and `--reconstruction-weights` on synthetic demo.
- Retained all v0.8 domain-aware dataset hub, simulation/generation, visuals, GPU-CVAE and experimental import workflows.

## Tests and limits

- 99 automated tests passed under the available Python container (88 legacy + 11 v0.9).
- No physical experimental reconstruction quality validation; no full-dataset (23.4 GB) benchmark in the release environment.
- Actual upstream PATATO code was inspected through public repository, but *not installed/executed* in this build environment; mocked API contract smoke test only.
- PATbox source link could not be resolved to retrievable MATLAB files; no verified port or equivalence claim. Many independent beamformer methods are exploratory proxies.
- Checkpoint-backed learning requires user-generated paired synthetic data; checkpoints are NOT bundled; Deep Image Prior is untrained/self-supervised for each acquisition.
- New methods extend **the algorithms**, not 3D physics or experimental time-zero, transducer/electronics/fluence calibration.
