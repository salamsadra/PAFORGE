# PA-FORGE v0.5 (2026-11-01)

- Added digital-twin reconstruction dataset Zenodo 15388429, small 4.8 MB IPASC sample in starter profile.
- Added strict HDF5 inventory command for unknown experimental array layouts.
- Added explicit external reconstruction bridge, requiring a separately reviewed and installed module.
- Added synthetic forward-model mismatch benchmark, metrics and comparative images.
- Preserved all v0.4 functionality, tests, source license advisories and noise-OFF default.
- Scope remains 2D, numerical and research-prototype only. 3D and real-device validation not claimed.
- Zenodo 23348355 could not be independently resolved or inspected; no upstream method copied.
