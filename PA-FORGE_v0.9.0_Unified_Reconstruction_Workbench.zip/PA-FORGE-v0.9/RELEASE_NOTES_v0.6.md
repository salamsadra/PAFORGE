# PA-FORGE v0.6 — Experiment-informed Generation & Research Dashboard

## New executable modules

- `experimental_learning.py`: InVision ZIP material-mask ingestion and TRAIN-only optical statistics; group-disjoint train/val/test; units explicitly set, matched wavelengths.
- `material_cvae.py`: conditional categorical material-mask CVAE with composition conditioning; validation loss, reproducible seeds, source/checkpoint metadata, train loss figure; separate from the vascular CVAE.
- `informed_phantom.py`: newly sampled 2D phantom material labels and train-derived optical coefficients drive existing optical approximation and original acoustic forward solver. Outputs **synthetic raw signals AND reconstructed images**.
- `ipasc_bridge.py`: direct single-click planar IPASC extraction/import with original detector coordinates, sampling clock and origin labels.
- `experimental_reconstruction.py`: `filtered_ubp`, `adjoint_fdtd`, nonnegative regularized `fista` plus previous UBP/DAS. Antialiased time decimation, explicit measured geometry, FOV containment guard, model assumptions and per-run manifest.
- `ui.py`: seven dashboard tabs for full local workflow including budgeted downloads, single-phantom extraction, ingestion, CVAE training, generation, experimental reconstruction, orientation display and benchmarks.
- `cli.py`: equivalent PowerShell commands; original commands backward-compatible.

## Validation boundaries

New v0.6 tests exercise all features using **manufactured numerical fixtures**, not downloaded experimental data. The real InVision HDF5 was tested on the user's Windows system with v0.5.1 UBP only; v0.6's newly added model-training and FISTA real-data results are *not* verified in this environment. No 3D functionality or actual PATbox MATLAB port is claimed.
