# PA-FORGE v0.7.0 Release Notes

## New
- Goal-aware Dataset Wizard with mandatory source logic, Auto/Starter/Recommended/Complete profiles, publisher metadata discovery, disk preflight, saved plan, resumable downloads and checksum verification.
- Full OpenQPAIData + Digital Twin corpus planning (approximately 23.4 GB compressed for both complete records).
- Multi-device corpus preparation from InVision and TROPUS 2D maps plus selected SVOT 3D-label slices.
- Mandatory DIS archive inventory and material-mapping audit for the complete optical-reference preparation workflow.
- Phantom-group-balanced CVAE training and group-balanced empirical mask sampling.
- One-click local launcher (`START_PA_FORGE.bat`) and dashboard dependency manager for Gradio/PyTorch CPU.
- Visual Data Explorer for publisher reference images, labels, mapped optical maps, measured sinograms/time traces, DIS distributions and SVOT volume slices.
- Generated-sample gallery for initial pressure, labels, reconstruction, raw signal sinogram, time traces and distributions.
- CLI commands for dataset plans, plan downloads, archive inventory and multi-device corpus preparation.

## Preserved
- Existing procedural anatomy, vascular CVAE, optical/acoustic forward simulation, noise engines, synthetic reconstruction benchmarks, experimental acquisition import and experimental reconstruction methods.
- Experimental methods: DAS, UBP, filtered UBP, adjoint FDTD and FISTA.

## Scientific safeguards
- OpenQPAIData material labels are not relabelled as artery/vein/capillary masks.
- SVOT raw detector signals are not fabricated; its shared 3D reference data contributes sampled labels/volumes only.
- DIS arrays are inventoried in native units and are not silently fused into the mapped optical profile without verifying the material mapping.
- Digital Twin QA data remains separate from OpenQPAIData training.
- All generated waveforms and reconstructions remain synthetic.

## Verification
- Automated suite: 74 passed in the build environment.
- UI construction verified.
- Dataset preparation, optical profile, material-CVAE, visualization and download-plan tests use small controlled fixtures.
- Full 23.4 GB dataset download and full-corpus processing are not claimed as executed in the build environment.
