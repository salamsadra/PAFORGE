# PA-FORGE v0.8.0 — Domain-aware dataset integrations and GPU training

## Added
- Twelve-role dataset catalogue (`paforge/dataset_registry.py`) with structured source semantics, scientific exclusions and status. Publisher-backed registration is distinct from full schema validation.
- Independent destination-folder downloads for Cambridge PATATO and user-supplied Zenodo record 23348355; Cambridge asset discovery uses publisher DSpace metadata; Zenodo uses publisher API/filenames/checksums where supplied. The Zenodo record was not independently accessible in the build environment.
- Per-dataset GB budgets for complete **whole** publisher files, with required OpenQPAIData optical/material inputs protected.
- Source-aware local ZIP/TAR.XZ/HDF5/MAT/NPZ/NPY inventory, original-data preview images and acoustic traces, archive traversal checks and no arbitrary publisher-code execution.
- Synthetic Vascularized Skin four-array paired reference export with exact schema gates and synthetic provenance.
- PATATO HDF5 frame/wavelength/measured-geometry-to-native-2D converter and publisher-reference extraction; nonplanar and missing metadata rejected.
- Optional CUDA and Apple MPS material-CVAE training via torch, with selected device and validation batching.
- Tab 09 for catalog, local publisher download, domain inspection and conversion. Tab 03 caps, Tab 04 device selection and Tab 00 GPU information.
- CLI `catalog`, `inspect-source`, `preview-source`, `extract-skin-pairs`, `import-patato` and independent `--budget`/`--device` options.

## Not implemented or not publisher-validated
- Arbitrary OADAT/PAISKINTONE/ShanghaiTech experimental source auto-reconstruction without real source geometry, axis and acquisition-rate verification.
- Learning a material CVAE from skin synthetic fields or clinical image datasets without a validated domain-specific model.
- Faithful MATLAB PATbox source port; the claimed Zenodo source contents have not been verified.
- Actual full-corpus download/training or GPU-hardware performance certification.

## Validation
`python -m pytest -q --disable-warnings --maxfail=1`: 88 passed locally on synthetic fixtures. No third-party publisher datasets are included inside the release archive.
