# PA-FORGE v0.5 — 2D reconstruction and experimental-data readiness sprint

**Release type:** executable research prototype + numerical study, **not** experimentally validated software.

## Key finding

PA-FORGE v0.5 is **2D**: a finite-difference time-domain (FDTD) simulation of a two-dimensional pressure field, with 2D reconstruction. Storing detector positions as `N x 3` does not constitute a 3D propagation model. No physically validated 3D implementation is present.

### Existing capabilities preserved

* Five selectable phantom modes: forearm, skin, breast, carotid/neck, standalone vascular networks; vessel categories available for vascular mode.
* Optional procedural and pretrained-weight-conditional CVAE generators. **No human-data-pretrained model is bundled.**
* Simplified wavelength-dependent optical model, approximate heterogeneous 2D acoustic FDTD, noise OFF/ON with five optional noise engines, raw multichannel signals, ground truth and 2D reconstructions.
* Existing user interface, dataset hub, native HDF5 exports, and experimental metadata-aware extraction.

### New in v0.5

* **Digital-twin reconstruction dataset** (Zenodo 15388429) added to the dataset hub with `ipasc_file.hdf5` (4.8 MB) and publisher README chosen in the starter profile; does **not** automatically pull the 2.9 GB `data.zip`.
* Existing OpenQPAIData starter pins `invision.zip` (~238 MB), `DIS.zip` (~132 MB), material metadata and README.
* `inventory-hdf5`: non-destructive metadata and array shape audit; original dataset axes are **not assumed**.
* `benchmark-mismatch`: synthetic-only reconstruction experiment comparing simple DAS, derivative backprojection, matched iterative FDTD and iterative FDTD with **incorrect homogeneous** sound speed.
* `reconstruct-plugin`: optional external reconstruction module interface. This allows wrapping an independently obtained reference reconstruction package (including a package from Zenodo) **after the external code and license are inspected**. It does not claim that a particular unknown external package was installed, run, or shown inferior.
* Paper draft (DOCX + PDF, separate from ZIP) and explicit verification protocol.

## Install

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
pip install -e ".[dev,ui,train]"
pytest -q
```

## Reproduce *executed* numerical study

```bash
paforge benchmark-mismatch \
  --output experiments/mismatch \
  --seeds 3 --grid 48 --transducers 20 \
  --time-steps 175 --iterations 8 \
  --assumed-sound-m-s 1630
```

Output: `metrics.csv`, `results.json`, `figure_model_mismatch.png`, `figure_metrics.png`.

**Interpretation:** the matched FDTD result is an inverse-crime consistency test. The mismatched result still shares the basic discretization and synthetic anatomy; it is NOT a real-device or sim-to-real validation.

## Download small real research inputs on your network-connected computer

```bash
paforge research-sources
paforge datasets inspect digital-twin-iqa
paforge datasets download --dataset digital-twin-iqa \
  --profile starter --accept-licenses --max-file-gb 0.2 \
  --max-total-gb 0.3 --output data/external
paforge datasets download --dataset openqpai \
  --profile starter --accept-licenses --max-file-gb 0.5 \
  --max-total-gb 0.6 --output data/external
```

Assets stay in source-specific folders. **No human or phantom experimental file is bundled**. Downloads are user-initiated and require network connectivity. The dataset hub checks publisher checksums where reported; review each source license before use. If the download fails, review the per-file JSON report and try the direct publisher link.

> `DIS.zip` contains optical sample characterization, not detector waveforms. `invision.zip` contains experimental acquisitions. `ipasc_file.hdf5` is a lightweight standardized input for import and reconstruction interoperability; the complete 2.9 GB digital-twin benchmark includes additional data not present in this small sample.

## Inspect before interpreting physical geometry

```bash
paforge inventory-hdf5 data/external/digital-twin-iqa/ipasc_file.hdf5 \
  --output experiments/ipasc_inventory.json
```

Review dataset keys, shapes, acquisition sampling clock, detector coordinates, waveform units, wavelengths, coordinate frame, and dimensionality. The existing command `paforge extract-acquisition --help` requires an explicit map from each native array axis to detector and time dimensions, plus fixed indices for additional dimensions. Do not guess these values.

Once a real acquisition has been properly extracted with authentic measured positions, use `paforge reconstruct-acquisition` for qualitative 2D BP/DAS reconstructions. A dataset with materially 3D detector geometry cannot be truthfully treated as a calibrated 2D inversion without validation.

## External reconstruction plugin (experimental extension)

Trusted installed Python module `my_reconstruction_adapter` must implement:

```python
def reconstruct(traces, sampling_rate_hz, positions_m, image_size, fov_m):
    """Return a finite float [image_size, image_size] array."""
```

Then:

```bash
paforge reconstruct-plugin data/extracted/acquisition.h5 \
  --module my_reconstruction_adapter --grid 96 --fov-m 0.04 \
  --output experiments/external_reconstruction
```

**Unverified upstream record:** `https://zenodo.org/records/23348355`. Its contents were not accessible to this session. No native algorithm from that record has been incorporated; no comparative performance or superiority claim is warranted. The wrapper is an executable **integration mechanism**, not a verified native integration.

## What is still missing for a submission-quality experimental article?

1. Download `invision.zip`, `DIS.zip`, and `ipasc_file.hdf5` on a network-enabled machine; inspect native schemas and source-specific metadata and licenses.
2. Build verified adapters for actual arrays and detector positions; distinguish detector element poses, acoustic sampling, laser pulse timings, and wavelengths. Validate reconstruction against supplied reference masks, not only visual plausibility.
3. Fit any device/noise/optical calibration on **training phantoms** only; freeze it before test evaluation. Split by physical phantom, not by correlated frames.
4. Compare with independent k-Wave/PATATO/official algorithm implementations on the *same raw acquisitions*, with the same preprocessing and image grid. Report runtimes, memory, sensitivity, and uncertainty; test cross-device generalization.
5. Inspect the linked record `23348355` before using its algorithm or describing PA-FORGE as a second/superior version of it.
6. For legitimate **3D** claims, separately implement and verify a true volumetric acoustic solver and 3D reconstruction with physically appropriate 3D source/detector geometry.

## Ethical and scientific reporting

The v0.5 benchmark is **numerical evidence only**. The draft paper explicitly labels it as such and leaves real-data results as pending. Do not submit this draft as a validated sim-to-real or superior-reconstruction claim until the real experimental tests above have been run.
