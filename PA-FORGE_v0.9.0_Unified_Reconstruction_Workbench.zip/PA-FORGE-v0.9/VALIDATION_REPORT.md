# PA-FORGE v0.9 — Validation Record

| Test | Observed |
|---|---|
| Full `pytest -q` suite | **99 passed** |
| Legacy regression tests | 88 passed |
| v0.9 new integration tests | 11 passed |
| UI build | Passed, 478 Gradio blocks created |
| Toy ray forward / discrete adjoint dot-product | Agreement to numerical floating-point tolerance |
| Synthetic-vs-native-HDF5 2D identical reconstruction (CF-DAS) | Passed numerical array comparison |
| End-to-end synthetic physical waveform → new methods → image/ZIP | Passed with generated synthetic fixture |
| 7-method comparison manifest + diagnostic plots | Passed using controlled synthetic source |
| U-Net/ResCNN checkpoint training, inference, group-split | Passed on small fixture data |
| Deep Image Prior self-supervised fit | Executed on synthetic fixture |
| PATATO external bridge with mocked documented API | Passed mocked integration only |
| Actual PATATO package installed and executed | **NOT TESTED** (runtime download unavailable) |
| Original PATbox MATLAB package retrieved and port parity | **NOT TESTED** (source unavailable) |
| Complete ~23.4 GB dataset / real experimental performance | **NOT TESTED** |
| Actual GPU/CUDA training hardware | **NOT TESTED** (only CPU PyTorch smoke) |
| Experimental scanner impulse/response/time-zero calibrated | **NOT CALIBRATED** |

## Science caveat

Passing unit tests establishes code consistency on fixtures. It does not establish that any of the 33 methods is quantitatively accurate on a particular real scanner. Models do not include all scanner impulse response, geometric 3D effects, acoustic attenuation or calibrated optical absorption. The 2D full-wave synthetic FISTA baseline is matched to the simulator itself (inverse crime). New ray-model iterative methods use a surrogate forward operator that differs from the FDTD forward acoustic model. Model-based and image-based learned methods require group-disjoint evaluation on held-out source phantoms and real measurements before any empirical claim.
