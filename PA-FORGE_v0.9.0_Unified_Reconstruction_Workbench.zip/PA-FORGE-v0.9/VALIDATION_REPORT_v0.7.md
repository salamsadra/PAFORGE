# PA-FORGE v0.7.0 — Software Validation Report

## Test environment
- Python runtime: build environment Python 3.13
- PyTorch available: CPU build
- Gradio available: 6.x
- Tests use controlled numerical and ZIP/HDF5 fixtures unless explicitly stated.

## Automated tests

```text
78 passed
```

The suite covers:
- legacy procedural simulation, noise and synthetic reconstruction;
- CLI commands and Gradio Blocks construction;
- publisher download safety, checksum verification, resume and ZIP traversal guards;
- dataset wizard mandatory-source planning, complete asset selection, disk preflight and download report;
- multi-device InVision/TROPUS material-map preparation and SVOT slice sampling;
- phantom-group-disjoint optical profiles and balanced training inputs;
- DIS NPZ inventory and material-mapping retention;
- source dataset visual panels and measured signal plots;
- DIS and SVOT diagnostic plots;
- experimental DAS/UBP/filtered UBP/adjoint FDTD/FISTA on controlled synthetic fixtures;
- experiment-informed synthetic raw-signal and reconstruction export.

## What these tests do not establish
- The complete 20.5 GB OpenQPAIData archive was not downloaded in the build environment.
- The 2.9 GB Digital Twin `data.zip` was not ingested in the build environment.
- No new material CVAE was trained on the full publisher corpus in the build environment.
- No new generated sample was validated against held-out real acquisition data.
- No 3D acoustic FDTD or clinical/human tissue validation is claimed.

## Full-data user test
Follow `FULL_DATASET_TEST_PROTOCOL.md`. The wizard will discover publisher file sizes and perform a local disk preflight before downloading. The complete two-record corpus is approximately 23.4 GB compressed, plus the downloader's 2 GB reserve.
