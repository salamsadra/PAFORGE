# PA-FORGE v0.8.0 — Verification report

**Environment:** local Linux Python runtime, software fixtures; no source ZIPs containing the full publisher corpus, no verified external publisher REST calls, no CUDA/Apple MPS hardware acceptance test.

**Software-suite result:** `python -m pytest -q --disable-warnings --maxfail=1` → **88 tests passed** in the build environment. Dashboard construction successful. New tests in `tests/test_v08_domain_aware.py` cover typed roles/exclusions, publisher DSpace discovery via mocked metadata and external-host rejection, whole-file independent budget and mandatory optics, PATATO 4D acquisition shape and nonplanarity rejection, original source ZIP/NPZ visualization and path traversal, paired-synthetic-skin export, GPU-selection errors and new CLI commands.

**Scientific guardrails:** Cambridge PATATO HDF5 follows documented frame/wavelength/detector/time convention; native 2D reconstruction requires measured planar geometry and sampling rate. The 2D FISTA model is approximate. Optical references, simulated sinograms, experimental signals and published reconstruction images remain separate lanes and retain provenance.

**Known gaps:** Live third-party HTTP endpoints, complete OADAT/PATATO/PAISKINTONE/ShanghaiTech archives, actual CUDA/MPS training, PATbox MATLAB equivalence, simulator fidelity and independent external validation were **not** tested. The unverified Zenodo 23348355 record is never asserted to contain a particular codebase. Upstream repositories may impose licenses, private data or download limits. A publisher's file schema may differ from documentation: first inspect it; a failing safe adapter is preferred over fabricated physical metadata.

**Release integrity:** see `CHECKSUMS_v0.8.sha256` for SHA-256 hashes of the packaged source and documentation (excluding the manifest itself). This does not replace publisher-provided asset checksums.
