from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from PIL import Image

ROOT=Path(__file__).parent
OUT=ROOT/'manuscript'/'PA-FORGE_Preliminary_Research_Manuscript.docx'
D=Document()
sec=D.sections[0];sec.top_margin=Inches(.71);sec.bottom_margin=Inches(.66)
sec.left_margin=Inches(.86);sec.right_margin=Inches(.86)
normal=D.styles['Normal'];normal.font.name='Aptos';normal.font.size=Pt(9.6);normal.font.color.rgb=RGBColor(42,49,63)
normal.paragraph_format.space_after=Pt(4)
normal.paragraph_format.line_spacing=1.10
for name,size in [('Title',19),('Heading 1',12.5),('Heading 2',10.8)]:
    s=D.styles[name];s.font.name='Aptos Display';s.font.size=Pt(size);s.font.bold=True;s.font.color.rgb=RGBColor(22,60,82)
    s.paragraph_format.space_before=Pt(12);s.paragraph_format.space_after=Pt(5)
if 'Kicker' not in D.styles:
    s=D.styles.add_style('Kicker',WD_STYLE_TYPE.PARAGRAPH);s.font.name='Aptos';s.font.size=Pt(8);s.font.bold=True;s.font.color.rgb=RGBColor(16,122,132)
if 'Small' not in D.styles:
    s=D.styles.add_style('Small',WD_STYLE_TYPE.PARAGRAPH);s.font.name='Aptos';s.font.size=Pt(8);s.font.color.rgb=RGBColor(90,104,117)

def p(s='',style=None):return D.add_paragraph(s,style)
def h(s,level=1):return D.add_heading(s,level)
def b(heading,body):
    x=D.add_paragraph();r=x.add_run(heading+'  ');r.bold=True;x.add_run(body)
def note(s):
    x=D.add_paragraph(s,'Small');x.paragraph_format.space_before=Pt(2);return x

def table(header,rows):
    t=D.add_table(rows=1,cols=len(header));t.style='Light Shading Accent 1';t.alignment=WD_TABLE_ALIGNMENT.CENTER
    for c,tx in zip(t.rows[0].cells,header):
        c.text=str(tx);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
    for row in rows:
        cells=t.add_row().cells
        for c,tx in zip(cells,row):
            c.text=str(tx);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
    for row in t.rows:
        for cell in row.cells:
            for par in cell.paragraphs:
                for run in par.runs:run.font.size=Pt(8.5)
    return t

def fig(path,width=6.8,caption=''):
    x=D.add_paragraph();x.alignment=WD_ALIGN_PARAGRAPH.CENTER
    x.add_run().add_picture(str(path),width=Inches(width))
    c=D.add_paragraph(caption,'Small');c.alignment=WD_ALIGN_PARAGRAPH.CENTER

D.add_paragraph('COMPUTATIONAL PHOTOACOUSTIC IMAGING  /  WORKING MANUSCRIPT', 'Kicker')
t=D.add_paragraph(style='Title');t.add_run('PA-FORGE: A Modular 2D Photoacoustic Simulation and Reconstruction Benchmark with Explicit Acoustic Model-Mismatch Evaluation')
note('Research manuscript draft  •  1 November 2026  •  Authors and affiliations to be confirmed')
D.add_heading('Abstract',1)
p('Reliable evaluation of photoacoustic (PA) reconstruction methods requires raw detector measurements, known optical and acoustic properties, and carefully separated numerical and experimental evidence. We introduce PA-FORGE, a configurable two-dimensional (2D) research pipeline for generating anatomical and vascular phantoms, assigning simplified optical properties, simulating acoustic detector time series, and reconstructing initial-pressure images. The pipeline includes five phantom profiles, optional conditional variational autoencoder (CVAE) sampling when trained model weights are available, independent acquisition/noise settings, standardized native exports, and a framework for importing and comparing experimental HDF5 datasets. To quantify a limitation of numerical model-based reconstruction, we benchmark delay-and-sum, derivative backprojection and iterative FDTD reconstructions under matched and deliberately mismatched sound-speed assumptions. Across three independent synthetic vessel phantoms evaluated in clean and noisy conditions, matched iterative inversion achieved mean Pearson correlation 0.853, falling to 0.371 under homogeneous model mismatch; derivative backprojection achieved 0.320. These are synthetic numerical outcomes, not experimental superiority or simulation-to-real generalization. We present the pipeline as an open, reproducible foundation and specify the additional experimental validations required before broader claims can be made.')
note('Keywords: photoacoustic tomography; numerical simulation; vessel phantoms; model mismatch; inverse problems; experimental validation; reproducible software')

h('1. Introduction')
p('Photoacoustic imaging uses optical absorption to generate broadband acoustic signals and reconstruct tissue contrast. Quantitative interpretation requires control of illumination, optical absorption, acoustic propagation, detector response and reconstruction. Even when an algorithm performs strongly on a simulator’s own observations, changes in tissue sound speed or device transfer functions can degrade its performance. Accessible tools for systematically separating these effects are consequently valuable.')
p('We developed PA-FORGE to unify anatomical phantom creation, acoustically simulated raw traces, reconstruction, optional noise, and dataset provenance. Its present scope is deliberately narrower than clinical tomography: the wave simulation is 2D and approximate, optical fluence is modeled with a simplified proxy, and real-data validation is pending. The contribution evaluated here is a reproducible stress-test methodology, rather than a claim to outperform established reconstruction software or a published digital-twin framework [1–5].')

h('2. Background and relationship to prior work')
p('The IPASC format and PACFISH establish a consensus HDF5 framework for raw PA measurements and metadata [1]. PATATO provides an established open-source analysis and reconstruction toolkit with IPASC support [2]. k-Wave provides validated k-space modeling in one, two and three dimensions [3]. Gröhl and colleagues introduced experimentally calibrated digital twins for full-reference reconstruction assessment and demonstrated an efficient FFT-based circular-geometry algorithm [4]. OpenQPAIData supplies measured raw acquisitions, reference labels, and matched material characterization across experimental instruments [5]. PA-FORGE should be assessed against these mature tools under identical acquisition and evaluation protocols; the present code does not establish a performance advantage over any of them.')

h('3. Methods')
h('3.1. Phantom and pressure generation',2)
p('PA-FORGE offers five illustrative 2D phantom modes: forearm, skin, breast, carotid/neck, and standalone vascular networks. The vascular mode distinguishes arterial, venous and capillary masks. Procedural generation is currently the default. Optional conditional VAE modules are implemented but require explicitly supplied model weights; no pretrained model certified on human anatomy is bundled. The photoacoustic initial-pressure relation is p₀(r, λ) = Γ(r) μₐ(r, λ) Φ(r, λ), where Γ denotes the Grüneisen parameter, μₐ absorption, and Φ local fluence. The current illumination approximation is not a Monte Carlo optical transport solver.')
h('3.2. Acoustic forward and detector models',2)
p('Pressure propagation is approximated using an explicit second-order finite-difference time-domain scheme on a 2D square grid with absorbing sponge boundaries. Detector signals are sampled through bilinear interpolation from simulated pressure fields. Instrument bandwidth filtering is optional; five distinct noise generators can be enabled separately or jointly. When noise is disabled, no stochastic noise is injected. The present model does not include calibrated detector directivity, realistic acoustic power-law attenuation or a full 3D measurement operator.')
h('3.3. Reconstruction and numerical objectives',2)
p('We compare unweighted delay-and-sum (DAS), heuristic derivative-weighted backprojection, and nonnegative regularized FDTD inversion. The iterative inverse minimizes ½‖Ap − y‖²₂ + (λ/2)‖p‖²₂ subject to p ≥ 0, using a matched discrete adjoint and projected FISTA-style updates; A is the numerical acoustic propagation/detector operator and y the recorded multichannel trace array. The exact generating forward operator produces an inverse crime baseline. We also reconstruct using a spatially homogeneous, intentionally incorrect sound-speed field to expose sensitivity to physical-model mismatch.')

h('4. Reproducible numerical experiment')
p('We used three procedurally generated vascular phantoms (random seeds 17, 29 and 41), each evaluated with added noise OFF and with Gaussian plus correlated noise ON. Simulations used a 48×48 grid, 20 sensors, 175 time samples and eight iterative updates. All reconstruction methods received the same numerical detector traces for each condition. The mismatched inversion assumed a constant sound speed of 1630 m/s rather than the spatially varying field used by the simulator. The primary metric was Pearson correlation with the known synthetic initial-pressure map. Oracle-scale normalized RMSE was retained only as a synthetic diagnostic and must not be transferred unmodified to unlabeled measurements.')
D.add_page_break()
h('5. Results')
table(['Method','Mean Pearson r','Mean oracle-scale NRMSE','Mean runtime (s)'],[
    ['DAS','−0.113','0.988','0.0010'],['Derivative BP','0.320','0.862','0.0022'],
    ['Iterative, homogeneous mismatch','0.371','0.834','0.5269'],
    ['Iterative, exactly matched (inverse crime)','0.853','0.456','0.5660']])
note('Table 1. Descriptive averages over three independent synthetic phantoms each evaluated under two noise settings (six paired conditions per method). Runtime depends on hardware and implementation. No statistical significance or experimental accuracy claim is made.')
fig(ROOT/'experiments/mismatch/figure_model_mismatch.png',6.78,'Figure 1. Example vascular phantom, synthetic traces, sound-speed map and reconstructions. The exactly matched case is an inverse-crime reference; the mismatched case assumes homogeneous sound speed.')
p('The exactly matched inverse recovered more structural similarity than the intentionally mismatched inverse. The drop in correlation from 0.853 to 0.371 is substantial, but it does not isolate a single real-world device error, prove robustness, or establish that one algorithm would outperform another on experimental measurements. The observation is that using a correct operator is integral to successful iterative reconstruction.')

h('6. Experimental datasets and future evaluation protocol')
p('The next stage is defined around three small public inputs. The 4.8 MB ipasc_file.hdf5 (Zenodo 15388429) provides a manageable standardized acquisition/metadata interoperability test, but not the complete digital-twin benchmark. invision.zip (approximately 238.1 MB) from OpenQPAIData provides experimental device measurements, while DIS.zip (approximately 132.1 MB) supplies independent optical material characterization rather than detector traces. Their published MD5 digests are recorded in the project manifest. The actual file bytes were not accessible in the current execution environment; no experimental image reconstruction or phantom-ground-truth comparison is reported in this manuscript.')
p('A valid experimental study will (i) inspect source schemas, units, time sampling, coordinate frames and licensing; (ii) establish group-disjoint partitions by physical phantom and acquisition device; (iii) estimate optical, acoustic and device parameters using training phantoms only; (iv) freeze those estimates before any evaluation on held-out phantoms; and (v) compare identical raw inputs across PA-FORGE, established PATATO/k-Wave methods and any independently verified external reconstruction package. Endpoints will include image fidelity against available reference masks, localization and resolution, reconstruction-time and memory profiles, and uncertainty under device and sound-speed shifts.')

h('7. Discussion and limitations')
p('The benchmark illustrates why model-matched synthetic performance is inadequate as evidence of clinical or experimental effectiveness. Our generic acoustic-wave propagation model is limited by a two-dimensional approximation; registration between a three-dimensional experimental measurement geometry and a 2D imaging plane may be invalid. The optical component uses an attenuation proxy rather than photon transport, and the detector model omits calibrated directionality and attenuation. The generative CVAE modules are implemented as trainable components but are not validated on human-derived masks. Small training samples from a single imaging device also cannot justify generalization to new anatomies or hardware.')
p('A user-provided Zenodo reconstruction record (23348355) could not be independently resolved or inspected in the current environment. We therefore supply a well-defined third-party Python adapter interface, but do not attribute any algorithm to that record or present a head-to-head comparison. Claims that PA-FORGE is a “second” or “superior” version of that package must await verification of its method, license, input assumptions and matched empirical testing.')

h('8. Conclusion')
p('PA-FORGE v0.5 integrates configurable 2D phantom generation, numerical PA waveforms, iterative and baseline reconstruction, noise control, dataset inventory, and reproducible model-mismatch testing. Across the present synthetic vascular benchmark, model-correct iterative reconstruction produced stronger correlation with synthetic truth than reconstruction using an incorrect homogeneous sound-speed assumption. These results motivate physical and experimental calibration but do not yet demonstrate simulation-to-real transfer or method superiority. Real-data validation and independent solver comparison are necessary before submission as an experimentally validated reconstruction paper.')

h('References')
refs=[
'[1] Gröhl, J. et al. (2022). The IPASC data format: A consensus data format for photoacoustic imaging. Photoacoustics, 26, 100339. https://doi.org/10.1016/j.pacs.2022.100339',
'[2] Else, T. R., Gröhl, J., Hacker, L., & Bohndiek, S. E. (2024). PATATO: A Python photoacoustic tomography analysis toolkit. Journal of Open Source Software, 9(93), 5686. https://doi.org/10.21105/joss.05686',
'[3] Treeby, B. E., & Cox, B. T. (2010). k-Wave: MATLAB toolbox for the simulation and reconstruction of photoacoustic wave fields. Journal of Biomedical Optics, 15(2), 021314. https://doi.org/10.1117/1.3360308',
'[4] Gröhl, J. et al. (2025). Digital twins enable full-reference quality assessment of photoacoustic image reconstructions. Journal of the Acoustical Society of America, 158, 590–601. https://doi.org/10.1121/10.0037188',
'[5] Gröhl, J. et al. (2026). OpenQPAIData: Measurements of test objects with reference labels for quantitative photoacoustic imaging research. Scientific Data, 13, 1127. https://doi.org/10.1038/s41597-026-08004-6',
'[6] Gröhl, J. et al. (2025). Data supplementing “Digital twins enable full-reference quality assessment of photoacoustic image reconstructions.” Zenodo. https://doi.org/10.5281/zenodo.15388429',
'[7] Gröhl, J. et al. (2024). OpenQPAIData, version 1 [Dataset]. Zenodo. https://doi.org/10.5281/zenodo.14044853',
]
for line in refs:
    par=D.add_paragraph(line,'Small');par.paragraph_format.space_after=Pt(2)

foot=sec.footer.paragraphs[0];foot.text='PA-FORGE v0.5  •  Preliminary numerical research draft  •  Not experimental validation'
foot.style='Small';foot.alignment=WD_ALIGN_PARAGRAPH.CENTER
OUT.parent.mkdir(parents=True,exist_ok=True)
D.save(OUT)
print(OUT)
