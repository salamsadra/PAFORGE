"""PA-FORGE: configurable 2D photoacoustic research software.

Experimental measured-data reconstruction is exploratory; generated outputs
are always synthetic and must not be misrepresented as measured acquisitions.
"""
__version__ = "0.7.0"
