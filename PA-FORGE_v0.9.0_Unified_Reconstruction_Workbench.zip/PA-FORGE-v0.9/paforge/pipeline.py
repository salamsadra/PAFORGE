"""Reproducible end-to-end photoacoustic forward simulation orchestration."""
from dataclasses import dataclass
import numpy as np
from .config import SimConfig
from .anatomy import generate_tissue
from .acoustic import simulate_pressure,apply_detector_filter,reconstruct_das,reconstruct_ubp
from .noise import add_noise, measured_added_snr_db
from .io import export_result


@dataclass
class SampleResult:
    tissue: object
    clean_signals: np.ndarray
    raw_signals: np.ndarray
    noise_components: dict
    dt_s: float
    detectors_m: np.ndarray
    reconstruction: np.ndarray | None
    info: dict


def simulate(config: SimConfig, index: int=0) -> SampleResult:
    if index<0:raise ValueError("index must be nonnegative")
    # Deterministically isolate random streams: toggling noise cannot modify anatomy.
    seed=np.random.SeedSequence([config.seed,index])
    a,n,l=seed.spawn(3)
    rng_anatomy=np.random.default_rng(a);rng_noise=np.random.default_rng(n);rng_laser=np.random.default_rng(l)
    learned_prior=None
    learned_types=None
    if config.anatomy_engine=="vascular_cvae":
        from .vascular_cvae import sample
        learned_types=sample(config.generator_weights,rng_anatomy,config.grid_size)
    if config.anatomy_engine=="cvae":
        from .learned import sample_vessel_prior
        learned_prior=sample_vessel_prior(config, rng_anatomy)
    if config.anatomy=="material_phantom":
        from .informed_phantom import generate_material_phantom
        tissue=generate_material_phantom(config,rng_anatomy)
    else:
        tissue=generate_tissue(config,rng_anatomy,learned_prior,learned_types)
    jitter=0.
    if config.pulse_energy_jitter_fraction>0:
        jitter=float(rng_laser.normal(scale=config.pulse_energy_jitter_fraction))
        jitter=max(-.9,jitter)
        tissue.initial_pressure_pa*=1+jitter
        tissue.fluence_j_m2*=1+jitter
    waveform,dt,positions=simulate_pressure(tissue.initial_pressure_pa,tissue.sound_speed_m_s,config)
    clean=apply_detector_filter(waveform,dt,config)
    # Channel dropout is an ACQUISITION DEFECT, not an injected noise process.
    dropped=np.zeros(config.transducers,dtype=bool)
    if config.channel_dropout_probability>0:
        dropped = rng_laser.random(config.transducers)<config.channel_dropout_probability
        clean[dropped]=0.
    raw,components=add_noise(clean,config,rng_noise)
    inversion_losses=None
    from .reconstruction_engine import Acquisition, reconstruct as unified_reconstruct
    if not config.reconstruct:
        rec=None
    else:
        acq=Acquisition(raw,dt,positions,config.fov_m,config.grid_size,
                        1480.+config.sound_speed_offset_m_s,tissue.sound_speed_m_s,config.wavelength_nm)
        rec=unified_reconstruct(acq,config.reconstruction_method,
                                iterations=config.reconstruction_iterations,
                                reg=config.reconstruction_l2,time_decimate=1,
                                weights=config.reconstruction_weights)
    inversion_losses=None
    snr=measured_added_snr_db(clean,raw)
    info={"material_provenance":getattr(tissue,"provenance",None),
          "reconstruction_method":config.reconstruction_method,
          "inversion_losses":inversion_losses,
          "vascular_pattern":config.vascular_pattern if config.anatomy=="vascular" else None,
          "vascular_type_pixel_counts":{name:int((tissue.vessel_type_mask==typ).sum()) for typ,name in [(1,"artery"),(2,"vein"),(3,"capillary"),(4,"untyped")]},
          "sample_index":index,"sampling_rate_hz":1/dt,"dt_s":dt,"recording_duration_s":dt*config.time_steps,
          "computed_noise_snr_db":None if snr is None or not np.isfinite(snr) else float(snr),
          "noise_added":bool(components),"noise_components":list(components),
          "laser_energy_jitter_draw":jitter,"dropped_channels":np.flatnonzero(dropped).tolist(),
          "experimental_calibration":False,"solver":"approximate heterogeneous 2D wave equation, sponge boundaries",
          "optical_model":config.illumination_model+"; NOT optical Monte Carlo",
          "reconstruction":"PA-FORGE unified uncalibrated 2D reconstruction: " + config.reconstruction_method if rec is not None else None}
    return SampleResult(tissue,clean,raw,components,dt,positions,rec,info)


def run_batch(config: SimConfig,folder,callback=None):
    paths=[]
    for index in range(config.samples):
        result=simulate(config,index)
        p=export_result(folder,index,config,result.tissue,result.clean_signals,result.raw_signals,
                        result.noise_components,result.dt_s,result.detectors_m,result.reconstruction,result.info)
        paths.append(p)
        if callback:callback(index+1,config.samples,p)
    return paths
