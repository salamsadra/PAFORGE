# PA-FORGE v0.5 starter data: run in activated Windows PowerShell venv.
# This script downloads publisher-hosted data; it does NOT claim to validate them.
$ErrorActionPreference = 'Stop'
Write-Host 'Step 1: dataset metadata and licensing must be reviewed before download.'
paforge research-sources
Write-Host 'Step 2: small IPASC file + publisher README (if available).'
paforge datasets download --dataset digital-twin-iqa --profile starter --accept-licenses --max-file-gb 0.2 --max-total-gb 0.3 --output data/external
if ($LASTEXITCODE -ne 0) { throw 'Digital twin download failed: inspect upstream status and connectivity.' }
Write-Host 'Step 3: OpenQPAIData InVision and DIS measurements.'
paforge datasets download --dataset openqpai --profile starter --accept-licenses --max-file-gb 0.5 --max-total-gb 0.6 --output data/external
if ($LASTEXITCODE -ne 0) { throw 'OpenQPAIData download failed: inspect upstream status and connectivity.' }
Write-Host 'Step 4: inventory source HDF5 without inferring axes.'
$small = 'data/external/digital-twin-iqa/ipasc_file.hdf5'
if (Test-Path $small) { paforge inventory-hdf5 $small --output experiments/ipasc_inventory.json }
Write-Host 'Done acquiring. STOP before analysis until sensor metadata / detector axes are verified.'
